# SoftDev_CA
Software Development Continuous Assessments
Dependencies:
Need Java 7.0
Require Junit framework for testing:
https://github.com/junit-team/junit4/wiki/Download-and-Install

https://junit.org/junit5/docs/current/user-guide/#overview-getting-started
this is how to get up and running
